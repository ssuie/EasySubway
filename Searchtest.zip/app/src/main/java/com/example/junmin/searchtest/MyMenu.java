package com.example.junmin.searchtest;

import java.util.ArrayList;
import java.util.HashMap;

public class MyMenu {
    private ArrayList<String> riceMenu;
    private ArrayList<String> sideMenu;
    private ArrayList<String> dessertMenu;
    private ArrayList<String> subwayName;
    private HashMap<String, ArrayList<String>> mMenu;

    public MyMenu() {
        riceMenu                = new ArrayList<>();
        sideMenu              = new ArrayList<>();
        dessertMenu         = new ArrayList<>();
        mMenu                   = new HashMap<>();
        subwayName = new ArrayList<>();

        setRiceMenu();
        setSideMenu();
        setDessertMenu();
        setHashMap();
        setSubwayName();
    }

    private void setSubwayName(){

    }
    private void setRiceMenu() {
        riceMenu.add("kimchi");
        riceMenu.add("baconbogg");
        riceMenu.add("kkakddugi");
        riceMenu.add("baconjumukbob");
        riceMenu.add("soboro");
        riceMenu.add("care");
        riceMenu.add("chamchimayo");
        riceMenu.add("choco");
    }

    private void setSideMenu() {
        sideMenu.add("dubukimchi");
        sideMenu.add("sundubu");
        sideMenu.add("cheeze");
        sideMenu.add("tomato");
        sideMenu.add("walnut");
        sideMenu.add("gamja");
        sideMenu.add("ddukboggi");
        sideMenu.add("dubuzolim");
        sideMenu.add("musukbakji");
        sideMenu.add("yeungeun");
    }

    private void setDessertMenu() {
        dessertMenu.add("choco");
        dessertMenu.add("coffee");
        dessertMenu.add("crocang");
        dessertMenu.add("ddoddiachip");
        dessertMenu.add("eggsandwich");
        dessertMenu.add("yogurt");
    }

    private void setHashMap() {
        mMenu.put("rice", riceMenu);
        mMenu.put("side", sideMenu);
        mMenu.put("dessert", dessertMenu);
        mMenu.put("subway", subwayName);
    }

    // 각 메뉴 반환
    public ArrayList<String> getMenu(String menuTitle) { return mMenu.get(menuTitle); }
}
